1: CREATE TABLE students (name TEXT, grade REAL, class INTEGER);
Parameters: [('James', 3.5, 480), ('Yaxin', 2.5, 480), ('Li', 4.5, 450), ('Alex', 3.2, 450), ('Greg', 3.3, 480), ('Emily', 2.25, 450), ('James2', 2.25, 450)]
1: INSERT INTO students VALUES (?, ?, ?);
1: SELECT * FROM students ORDER BY class, name;
1: SELECT * FROM students ORDER BY name DESC;
