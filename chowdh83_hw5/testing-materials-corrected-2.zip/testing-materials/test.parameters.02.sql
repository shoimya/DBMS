1: CREATE TABLE students (name TEXT, grade REAL);
Parameters: [('James', 3.5), ('Li', 2.5)]
1: INSERT INTO students VALUES (?, ?);
1: SELECT * FROM students ORDER BY grade;
