1: CREATE TABLE student (name TEXT, grade REAL);
1: INSERT INTO student VALUES ('James', 3.5);
1: INSERT INTO student VALUES ('Yaxin', 4.0);
1: SELECT MAX(grade) FROM student ORDER BY grade;
1: INSERT INTO student VALUES ('Li', 4.1);
1: SELECT MAX(grade) FROM student ORDER BY grade;
