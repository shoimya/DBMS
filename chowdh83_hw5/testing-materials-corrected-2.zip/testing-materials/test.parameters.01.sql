1: CREATE TABLE students (name TEXT, grade REAL);
Parameters: [('James', 3.5), ('Yaxin', 2.5)]
1: INSERT INTO students VALUES (?, ?); 
