1: CREATE TABLE student (name TEXT, grade REAL, piazza INTEGER);
1: INSERT INTO student VALUES ('James', 3.5, 1), ('Yaxin', 3.51, 3), ('Li', 3.0, 2);
1: SELECT MAX(piazza) FROM student ORDER BY piazza;
