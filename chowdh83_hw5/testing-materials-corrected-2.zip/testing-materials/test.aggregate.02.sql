1: CREATE TABLE student (name TEXT, grade REAL);
1: INSERT INTO student VALUES ('James', 3.5), ('Yaxin', 3.51), ('Li', 3.0);
1: SELECT MIN(grade) FROM student ORDER BY grade;
